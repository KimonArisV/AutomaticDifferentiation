import numpy as np
import math
import heapq

def sin(obj):
    '''Takes Node type object as input. Returns Node with sin func'''
    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.sin_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def cos(obj):
    '''Takes Node type object as input. Returns Node with cos func'''
    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.cos_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def tan(obj):
    '''Takes Node type object as input. Returns Node with tan func'''
    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.tan_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root

def exp(obj):
    '''Takes Node type object as input. Returns Node with e^x func'''
    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.exp_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def arcsin(obj):
    '''Takes Node type object as input. Returns Node with arcsin func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.arcsin_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def arccos(obj):
    '''Takes Node type object as input. Returns Node with arccos func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.arccos_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def arctan(obj):
    '''Takes Node type object as input. Returns Node with arctan func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.rctan_eval, left=obj, right=None)
    root = Node.check_existence(root)
    return root


def sinh(obj):
    '''Takes Node type object as input. Returns Node with sinh func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.mult_eval, left=exp(obj) - exp(-obj), right=Node().nodify(2) ** -1)
    root = Node.check_existence(root)
    return root


def cosh(obj):
    '''Takes Node type object as input. Returns Node with cosh func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.mult_eval, left=exp(obj) + exp(-obj), right=Node().nodify(2) ** -1)
    root = Node.check_existence(root)
    return root


def tanh(obj):
    '''Takes Node type object as input. Returns Node with tanh func'''

    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.mult_eval, left=sinh(obj), right=cosh(obj) ** -1)
    root = Node.check_existence(root)
    return root


def logistic(obj):  # TODO: what is this?
    if type(obj) != Node:
        obj = Node().nodify(obj)

    root = Node(func=Node.mult_eval, left=Node.nodify(1), right= (1+exp(obj) )**-1)
    root = Node.check_existance(root)
    raise rootr


def log(obj, base=np.exp(1)):
    '''Takes Node type object as input. Returns Node with log method

    :param obj: Node
    :param base: int or float (default is natural log base e)
    '''
    if type(obj) != Node:
        obj = Node().nodify(obj)

    if type(base) != Node:
        base = Node().nodify(base)

    root = Node(func=Node.log_eval, left=obj, right=base)
    root = Node.check_existence(root)
    return root


class Node():
    """
    A single class implemeting Automatic Differentiation. 

    Objects of the Node() class can be used to define fuctions, evaluate the function with given values
    and calculate the derivaties with given seeds. Instances of Node() class should be created by calling Node().create_nodes(n:int) function. This 
    function returns n variables of type Node(), which can be used to build function. After a function, f:Node, is defined the user can call f.evaluate(values, seeds) which will return 
    value and derivatives. evaluate() can be called mutliple times. 

    Example:
    a, b, c = Node().create_nodes(3)

    d = (sin(a) + b)**2
    e = 3 + c + log(b, 2)

    f = [d, e]
    result = Node.evaluate(f, [np.pi,2, 4], [1, 1, 1])

    result:   
        (array([4., 8.]),
        array([[-4.        ,  4.        ,  0.        ],
        [ 0.        ,  0.72134752,  1.        ]]))

    The result of the function is tuple of two arrays. The first one retuns the value of the two functions,
    the second array holds an array of gradients at a given seed.

    Note:
    The order of the elemnets in the list passed as arguments: values and seeds to evaluate() 
    corresponds to the order to the nodes retuned by the call Node().create_nodes(n).
    """
    # Tree build
    _node_register = {}
    # eval level
    _eval_register = {}
    _n_vars = 0

    def __init__(self, val=None, deriv=None, right=None, left=None, func=None, hash_=None):
        self.val = val
        self.deriv = deriv
        self.left = left
        self.right = right
        self.func = func
        self.hash_ = hash_
        self.hash_list_ = []
        self._func_translation = {
            str(Node.const_eval)[:22]: "const",
            str(Node.exp_eval)[:22]: "exp",
            str(Node.tan_eval)[:22]: "tan",
            str(Node.cos_eval)[:22]: "cos",
            str(Node.sin_eval)[:22]: "sin",
            str(Node.neg_eval)[:22]: "neg",
            str(Node.pow_eval)[:22]: "^",
            str(Node.add_eval)[:22]: "+",
            str(Node.mult_eval)[:22]: "*",
            str(Node.arcsin_eval)[:22]: "arcsin",
            str(Node.arccos_eval)[:22]: "arccos",
            str(Node.arctan_eval)[:22]: "arctan",
            str(Node.log_eval)[:22]: "log",
        }

    def __str__(self):
        pretty_func = 'None' if not self.func else str(self.func).split()[1]
        pretty_str = f'Node(val:{self.val}, deriv:{self.deriv}, func:{pretty_func}, hash:{self.hash_})\n' + \
                     '\n|\n|-(L)->' + '\n|      '.join(str(self.left).split('\n')) + \
                     '\n|\n|-(R)->' + '\n|      '.join(str(self.right).split('\n'))
        return pretty_str

    @staticmethod
    def create_nodes(n: int):
        '''Takes input n number of variables. Returns single variable (n=1) or list of n variables as type Node'''
        Node._node_register = {}
        Node._n_vars = n
        for i in range(0, n):
            hash_ = chr(97 + i)
            Node._node_register[i] = Node(hash_=chr(97 + i))
            Node._node_register[hash_] = Node._node_register[i]
        if n == 1:
            return Node._node_register[0]
        else:
            return list(Node._node_register.values())[::2]

    @staticmethod
    def set_values(values, seeds):
        '''Input lists of values and list of seeds to store in the node register. Returns None'''
        assert len(values) == len(seeds), Exception('The two inputs must be of the same size.')

        for i in range(0, len(values)):
            Node._node_register[i].val = values[i]
            Node._node_register[i].deriv = np.zeros(len(values))
            if seeds[i] != 0:
                Node._node_register[i].deriv[i] = seeds[i]

    @staticmethod
    def evaluate(node, values, seeds=[]):
        ''' Evalutes and calculates derivatives of equation or vectors of equations
        :param node: equation or list of equations
        :param values: list of values to evaluate function at
        :param seeds: list of seeds to evaluate derivative at (optional, default set to 1)
        :return: list containing evaluated val, partial derivatives
        '''
        n_vars = Node._n_vars
        if n_vars != len(values):
            raise ValueError(f'Length of values must be equal to number of variables')
        Node._eval_register = {}

        if isinstance(node, Node):
            if len(seeds) == 0:
                seeds = np.ones(n_vars)
            Node.set_values(values, seeds)
            Node.eval_node(node)
            return node.val, node.deriv

        if isinstance(node, list):  # if it's a list, create seeds as list of ones if not set
            if len(seeds) == 0:
                seeds = list(np.ones(len(values)))
            elif len(seeds) != len(values):
                raise IndexError('Length of seeds must be equal to length of values')
            Node.set_values(values, seeds)

        if not isinstance(node, Node) and not isinstance(node, list):  # check that input is Node or a list
            raise TypeError(f'Input {node} must be type Node or list')
        else:
            vals, derivs = [], []
            # compute vector of equations
            for eq in node:
                Node.eval_node(eq)
                vals.append(eq.val)
                derivs.append(eq.deriv)
        return vals, derivs

    def nodify(self, other):
        if type(other) == Node:
            other_node = other
        else:
            other_node = Node(val=other, deriv=0, func = Node.const_eval)
            other_node.set_hash()
        return other_node

    @staticmethod
    def check_existence(node):
        node.set_hash()

        if node.hash_ in Node._node_register:
            return Node._node_register[node.hash_]
        Node._node_register[node.hash_] = node
        return node

    def set_hash(self):

        single_node_func = [
            Node.exp_eval, Node.neg_eval,
            Node.tan_eval, Node.cos_eval, Node.sin_eval,
            Node.arcsin_eval, Node.arccos_eval, Node.arctan_eval
        ]

        if self.hash_ is not None:
            return self.hash_

        hash_ = []
        if self.func == Node.const_eval:
            self.hash_ = str(hash(str(self.val) + str(self.func)[:22]))
            return
        if self.func in single_node_func:
            hash_.append(self.left.hash_)
            hash_.append(self._func_translation[str(self.func)[:22]])
            self.hash_ = str(hash(tuple(hash_)))
            return
        if self.func in [Node.pow_eval, Node.log_eval]:
            hash_.append(self.left.hash_)
            hash_.append(self.right.hash_)
            hash_.append(self._func_translation[str(self.func)[:22]])
            self.hash_ = str(hash(tuple(hash_)))
            return
        if self.left.hash_ <= self.right.hash_:
            first = self.left
            second = self.right
        else:
            first = self.right
            second = self.left
        if first.func == self.func:
            first_hash = first.hash_list
        else:
            first_hash = [first.hash_]
        if second.func == self.func:
            second_hash = second.hash_list
        else:
            second_hash = [second.hash_]
        self.hash_list = list(heapq.merge(first_hash, second_hash))
        # todo: check if this approach works without changing the hash list
        self.hash_ = str(hash(tuple(self.hash_list + [self._func_translation[str(self.func)[:22]]])))

    @staticmethod
    def eval_node(node):

        if node.left is not None and node.left.func != None:
            node.left.eval_node(node.left)
        if node.right is not None and node.right.func != None:
            node.right.eval_node(node.right)
        node.func(node)
        return node

    # Addition 
    def __add__(self, other):
        '''overload addition'''
        other_node = self.nodify(other)
        root = Node(func=Node.add_eval, left=self, right=other_node)
        root = Node.check_existence(root)
        return root

    def __radd__(self, other):
        '''overload addition'''
        other_node = self.nodify(other)

        root = Node(func=Node.add_eval, left=other_node, right=self)
        root = Node.check_existence(root)
        return root

    @staticmethod
    def const_eval(node):
        '''Evaluate constant node'''
        if not str(node.hash_) in Node._eval_register:
            Node._eval_register[str(node.hash_)] = 1

    @staticmethod   
    def add_eval(node):
        '''Evaluate addition of nodes'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right != None), 'Addition needs two nodes.'
            node.val = node.left.val + node.right.val
            node.deriv = node.left.deriv + node.right.deriv
            Node._eval_register[str(node.hash_)] = 1

    # Subtraction
    def __sub__(self, other):
        '''overload subtraction'''
        other_node = self.nodify(other)
        root = Node(func=Node.add_eval, left=self, right=-other_node)
        root = Node.check_existence(root)
        return root

    def __rsub__(self, other):
        '''overload subtraction'''
        other_node = self.nodify(other)
        root = Node(func=Node.add_eval, left=other_node, right=-self)
        root = Node.check_existence(root)
        return root

    def __neg__(self):
        '''overload negation'''
        root = Node(func=Node.neg_eval, left=self)
        root = Node.check_existence(root)
        return root

    @staticmethod
    def neg_eval(node):
        '''Evaluate subtraction of nodes'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None)
            node.val = -node.left.val
            node.deriv = -node.left.deriv
            Node._eval_register[node.hash_] = 1

    def __mul__(self, other):
        '''overload multiplication'''
        other_node = self.nodify(other)
        root = Node(func=Node.mult_eval, left=self, right=other_node)
        root = Node.check_existence(root)
        return root

    def __rmul__(self, other):
        '''overload multiplication'''
        other_node = self.nodify(other)
        root = Node(func=Node.mult_eval, left=other_node, right=self)
        root = Node.check_existence(root)
        return root

    @staticmethod
    def mult_eval(node):
        '''Evaluate multiplication of nodes'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right != None), 'Multiplication needs two nodes.'
            node.val = node.left.val * node.right.val
            node.deriv = node.left.deriv * node.right.val + node.left.val * node.right.deriv
            Node._eval_register[node.hash_] = 1

    def __truediv__(self, other):
        '''overload division'''

        other_node = self.nodify(other)
        root = Node(func=Node.mult_eval, left=self, right=other_node ** -1)
        root = Node.check_existence(root)
        return root

    def __rtruediv__(self, other):
        '''overload division'''
        other_node = self.nodify(other)
        root = Node(func=Node.mult_eval, left=other_node, right=self ** -1)
        root = Node.check_existence(root)
        return root

    def __pow__(self, other):
        '''overload power'''

        other_node = self.nodify(other)
        root = Node(func=Node.pow_eval, left=self, right=other_node)
        root = Node.check_existence(root)
        return root

    def __rpow__(self, other):
        '''overload power'''

        other_node = self.nodify(other)
        root = Node(func=Node.pow_eval, left=other_node, right=self)
        root = Node.check_existence(root)
        return root

    @staticmethod
    def pow_eval(node):
        '''Evaluate power function'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right != None), 'power function needs two nodes.'
            node.val = node.left.val ** node.right.val
            node.deriv = node.left.val ** node.right.val * (
                        node.right.val * node.left.deriv / node.left.val + node.right.deriv * np.log(node.left.val))
            Node._eval_register[node.hash_] = 1

    @staticmethod
    def sin_eval(node):
        '''Evaluate sin function'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'sin function needs one child'
            node.val = np.sin(node.left.val)
            node.deriv = np.cos(node.left.val) * node.left.deriv
            Node._eval_register[str(node.hash_)] = 1

    @staticmethod
    def cos_eval(node):
        '''Evaluate cos function'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'cos function needs one child'

            node.val = np.cos(node.left.val)
            node.deriv = -np.sin(node.left.val) * node.left.deriv
            Node._eval_register[node.hash_] = 1

    @staticmethod
    def tan_eval(node):
        '''Evaluate tan function'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'tan function needs one child'

            node.val = np.tan(node.left.val)
            node.deriv = (np.cos(node.left.val) ** -2) * node.left.deriv
            Node._eval_register[node.hash_] = 1

    @staticmethod
    def exp_eval(node):
        '''Evaluate e^x function'''

        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'exp function needs one child'

            node.val = np.exp(node.left.val)
            node.deriv = np.exp(node.left.val) * node.left.deriv
            Node._eval_register[node.hash_] = 1

    @staticmethod
    def arcsin_eval(node):
        '''Evaluate arcsin function'''

        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'arcsin function needs one child'
            node.val = np.arcsin(node.left.val)
            node.deriv = node.left.deriv / (np.sqrt(1 - node.left.val ** 2))
            Node._eval_register[str(node.hash_)] = 1

    @staticmethod
    def arccos_eval(node):
        '''Evaluate arccos function'''

        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'arcsin function needs one child'
            node.val = np.arccos(node.left.val)
            node.deriv = - node.left.deriv / (np.sqrt(1 - node.left.val ** 2))
            Node._eval_register[str(node.hash_)] = 1

    @staticmethod
    def arctan_eval(node):
        '''Evaluate arctan function'''
        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right == None), 'arcsin function needs one child'
            node.val = np.arctan(node.left.val)
            node.deriv = node.left.deriv / (1 + node.left.val ** 2)
            Node._eval_register[str(node.hash_)] = 1

    @staticmethod
    def log_eval(node):
        '''Evaluate log function'''

        if not str(node.hash_) in Node._eval_register:
            assert (node.left != None) and (node.right != None), 'Log needs two nodes.'
            node.val = math.log(node.left.val, node.right.val)
            node.deriv = node.left.deriv / (node.left.val * math.log(node.right.val))
            Node._eval_register[str(node.hash_)] = 1

    def __eq__(self, other):
        '''overload equality to compare Nodes'''
        if type(other) != Node:
            return False
        else:
            return self.hash_ == other.hash_

    def __neq__(self, other):
        '''overload neq to compare Nodes'''
        return not (self == other)