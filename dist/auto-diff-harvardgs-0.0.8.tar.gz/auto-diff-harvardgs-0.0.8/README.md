# cs107-FinalProject 

[![Build Status](https://app.travis-ci.com/cs107-gs/cs107-FinalProject.svg?token=ZtPs1X5aAxCrPAKikjMk&branch=travis-ci)](https://app.travis-ci.com/cs107-gs/cs107-FinalProject)
[![codecov](https://codecov.io/gh/cs107-gs/cs107-FinalProject/branch/main/graph/badge.svg?token=00ZJUACKVW)](https://codecov.io/gh/cs107-gs/cs107-FinalProject)

group number: 23

group members: 
  * Kimon Vogt
  * Anna Bialas
  * Hakon Grini
  * Iris Sheu
